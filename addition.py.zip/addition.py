print("calculator")
value =int(input("value1\n"))

value2 =int( input("value 2 \n"))

print("result")

print(value + value2)
 
